package com.example.lbuathier.demoformulaire;

import android.content.DialogInterface;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText edName;
    EditText edFirstName;
    EditText edBirthDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edName = findViewById(R.id.edName);
        edFirstName = findViewById(R.id.edFristName);
        edBirthDay = findViewById(R.id.edDate);
    }

    public void validate(View view) {
        Toast.makeText(getApplicationContext(), "bonjour \n" + edFirstName.getText().toString()
                + " " + edName.getText().toString(), Toast.LENGTH_SHORT).show();


        AlertDialog builder1 = new AlertDialog.Builder(MainActivity.this)
                .setMessage(edFirstName.getText().toString()
                        + " " + edName.getText().toString())
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Whatever...
                    }
                })
                .show();

    }

}
