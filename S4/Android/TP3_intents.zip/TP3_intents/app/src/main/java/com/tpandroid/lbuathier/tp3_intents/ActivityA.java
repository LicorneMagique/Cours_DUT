package com.tpandroid.lbuathier.tp3_intents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class ActivityA extends Activity {

    public static final String MESSAGE_FROM_A = "message_from_A";
    public static final String MESSAGE_FROM_B = "message_from_B";
    public static final String MESSAGE_FROM_C = "message_from_C";
    public static final int REQUEST_CODE_A = 1;
    public static final int REQUEST_CODE_B = 2;
    public static final int REQUEST_CODE_C = 3;

    private EditText edtTextA;
   // private TextView tvTextA;
    private TextView tvTitleTextBC;
    private TextView tvTextBC;
    Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a);
        edtTextA = (EditText) findViewById(R.id.edTextA);
        tvTitleTextBC = (TextView) findViewById(R.id.tvTitleTextBC);
        tvTextBC = (TextView) findViewById(R.id.tvTextBC);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        edtTextA.setText("");
    }

    public void onClickActivityB (View v){
        intent = new Intent(this, ActivityB.class);
        intent.putExtra(MESSAGE_FROM_A, edtTextA.getText().toString());
        startActivityForResult(intent, REQUEST_CODE_B);
    }

    public void onClickActivityC (View v){
        intent = new Intent(this, ActivityC.class);
        intent.putExtra(MESSAGE_FROM_A, edtTextA.getText().toString());
        startActivityForResult(intent, REQUEST_CODE_C);
    }

    public void onClickActivityD (View v) {
        intent = new Intent(ActivityA.this, ActivityD.class);
        startActivity(intent);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK ) {
            if (requestCode == REQUEST_CODE_B) {
                if (data.hasExtra(MESSAGE_FROM_B)) {
                    String result = data.getStringExtra(MESSAGE_FROM_B);
                    if (result != null && result.length() > 0) {
                        Toast.makeText(this, "from B : "+result, Toast.LENGTH_SHORT).show();
                        tvTitleTextBC.setText( "Activité B");
                        tvTextBC.setText(result);
                    }
                }
            }
            if (requestCode == REQUEST_CODE_C) {
                if (data.hasExtra(MESSAGE_FROM_C)) {
                    String result = data.getStringExtra(MESSAGE_FROM_C);
                    if (result != null && result.length() > 0) {
                        Toast.makeText(this, "from C : "+result, Toast.LENGTH_SHORT).show();
                        tvTitleTextBC.setText( "Activité C");
                        tvTextBC.setText(result);
                    }
                }
            }

        }
    }


}
