package com.tpandroid.lbuathier.tp3_intents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class ActivityB extends Activity {
    TextView tv;
    private Button btn  ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b);
        tv = (TextView) findViewById(R.id.tvActivityB);
        btn = (Button)findViewById(R.id.btnActivityB);
        String str = getIntent().getStringExtra(ActivityA.MESSAGE_FROM_A);
        tv.setText("message from A : \n "+str);

    }

    @Override
    public void finish() {
        Intent intentB = new Intent();
        EditText editText= (EditText) findViewById(R.id.edTextActivityB);
        String string = editText.getText().toString();
        intentB.putExtra(ActivityA.MESSAGE_FROM_B, string);
        setResult(RESULT_OK, intentB);
        super.finish();
    }

}
