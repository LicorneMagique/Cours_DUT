package com.tpandroid.lbuathier.tp3_intents;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;


public class ActivityC extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c);
        TextView tv = (TextView) findViewById(R.id.tvActivityC);

        String str = getIntent().getStringExtra(ActivityA.MESSAGE_FROM_A);
        tv.setText("message from A : \n "+str);
    }

    @Override
    public void finish() {
        Intent intentC = new Intent();
        EditText editText= (EditText) findViewById(R.id.edTextActivityC);
        String string = editText.getText().toString();
        intentC.putExtra(ActivityA.MESSAGE_FROM_C, string);
        setResult(RESULT_OK, intentC);
        super.finish();
    }
}
