package com.tpandroid.lbuathier.listviewcustom;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;


public class DetailActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TextView tv = (TextView) findViewById(R.id.tvDetail);
        ImageView img = (ImageView) findViewById(R.id.imageView);

        Intent intent = getIntent();
        HashMap<String, String> hashMap = (HashMap<String, String>)intent.getSerializableExtra("map");
        Log.v("HashMapTest", hashMap.get("titre"));
        tv.setText("voici le detail correspondant à " +hashMap.get("titre"));
        img.setImageResource(Integer.parseInt(hashMap.get("img")));
    }
}
